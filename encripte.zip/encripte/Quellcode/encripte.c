#include <stdio.h>
#include <string.h>

char c;

int array[8];
int f_out;
int binary_i;

unsigned long long key = 12379;
unsigned long long int encriptet_string;;

int main() {
    FILE* f;
    FILE* nf;

    f = fopen("Test.txt", "r");
    nf = fopen("encriptet.txt", "w");
    
    if (f != NULL) {
        while ((c = fgetc(f)) != EOF) {
            f_out = (int) c;

            converte(f_out);

            encripte(binary_i);

            fprintf(nf, "%llu", encriptet_string);
            fprintf(nf, "%s", ".");

            ///*
            printf("%i", f_out);
            printf("\n");
            printf("%llu", encriptet_string);
            printf("\n");
            printf("%i", binary_i);
            printf("\n");
            //*/
        }
    }

    fclose(f);
    fclose(nf);

    return 0;
}

int converte(int f_byte) {
    int pointer = 0;
    memset(array, -1, 8);

    int r;
    while (f_byte > 0) {
        r = f_byte%2;
        f_byte = f_byte/2;

        array[pointer] = r;
        pointer++;
    }

    int summe = 0;
    int multiplikator = 1;
    for (int j = 0; j <= 7; j++) {
        summe += array[j] * multiplikator;
        multiplikator *= 10;
    }

    binary_i = summe;

    return binary_i;
}

int encripte(unsigned long int in) {
    in *= 100;
    in += 79;

    encriptet_string = in * key;

    return encriptet_string;
}