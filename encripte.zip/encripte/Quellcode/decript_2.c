#include <stdio.h>
#include <string.h>

char c;
char b;
char p;

int u;
int ascii;

unsigned long long n;
unsigned long long sum;
unsigned long long multiplikator;
unsigned long long encriptet_string;
unsigned long long decriptet_string;
unsigned long long key = 12379;

int array[25];
int pointer = 1;

int bufferarray[8];
int bufferpointer = 0;
int buffermultiplikator = 1;

int decript(unsigned long long in) {
    decriptet_string = in / key;
    decriptet_string -= 79;
    decriptet_string /= 100;

    return decriptet_string;
}

int main() {
    FILE* f;
    FILE* nf;
    FILE* buffer;

    f = fopen("encriptet.txt", "r");
    nf = fopen("decriptet.txt", "w");
    buffer = fopen("buffer.txt", "r+");

    for (int g = 0; g <=26; g++) {
        array[g] = -1;
    }
    array[0] = -2;

    if (f != NULL) {
        for (int g = 0; g <=26; g++) {
            array[g] = -1;
        }

        array[0] = -2;

        while ((c = fgetc(f)) != EOF) {    
            if (c != '.') {
                if (c == '0') { n = 0; }
                if (c == '1') { n = 1; }
                if (c == '2') { n = 2; }
                if (c == '3') { n = 3; }
                if (c == '4') { n = 4; }
                if (c == '5') { n = 5; }
                if (c == '6') { n = 6; }
                if (c == '7') { n = 7; }
                if (c == '8') { n = 8; }
                if (c == '9') { n = 9; }

                array[pointer] = n;
                pointer++;
            }

            if (c == '.') {
                pointer = 1;
                sum = 0;
                multiplikator = 1;

                for (int j = 24; j >= 0; j--) {
                    if (array[j] > -1) {
                        sum += array[j] * multiplikator;
                        multiplikator *= 10;
                    }
                }

                decript(sum);
                fprintf(buffer, "%llu", decriptet_string);


                if (buffer != NULL) {
                    for (int g = 0; g <= 8; g++) {
                        bufferarray[g] = -1;
                    }

                    bufferpointer = 0;
                    while ((b = fgetc(buffer)) != EOF) {
                        if (b == '0') { u = 0; }
                        if (b == '1') { u = 1; }

                        array[bufferpointer] = u;
                        bufferpointer++;
                    }

                    buffermultiplikator = 1;
                    for (int v = 8; v >= 0; v--) {
                        if (bufferarray[v] > -1) {
                            ascii += bufferarray[v] * buffermultiplikator;
                            buffermultiplikator *= 2;
                        }
                        
                        p = (char) ascii;
                        printf("%c", p);
                    }
                }


                printf("\n");
                printf("%llu", sum);
                printf("\n");
                printf("%llu", decriptet_string);
                printf("\n");
            }
        }
    }

    return 0;
}